package Smartphone_dealership;

public class employee {

	String name;
	int id;
	public employee(String name,int id) {
		this.name=name;
		this.id=id;
	}
	public void sellphone(customer cm,smartphone sm) {
		if(cm.cash>=sm.price) {
			System.out.println("Sold the smartphone to customer : "+cm);
		}
		else {
			emi(sm);
		}
	}
	public void emi(smartphone sm) {
		double emi=sm.price*1.0/12.0;System.out.println("The 12 months emi for buying the smartphone is : "+emi);
		
		
	}
}
