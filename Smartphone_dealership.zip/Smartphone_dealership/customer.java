package Smartphone_dealership;

public class customer {

	String name;
	int cash;
	public customer(String name,int cash) {
		this.name=name;
		this.cash=cash;
	}
	public void buy(smartphone sm1) {
		System.out.println("Trying to buy smartphone"+sm1);
	}	
	@Override
	public String toString() {
		return this.name;
	}
}
