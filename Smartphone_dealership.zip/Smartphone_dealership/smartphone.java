package Smartphone_dealership;

import java.util.*;

public class smartphone {
String model_name;
int price;
String color;
public smartphone(String model_name,int price,String color) {
	this.model_name=model_name;
	this.price=price;
	this.color=color;
	
}
@Override
public String toString()
{
	return this.model_name+" "+this.color+" "+this.price;
}
}

