package Smartphone_dealership;
import java.io.*;
public class main {

	public static void main(String[] args) throws IOException {
		
		smartphone sm1=new smartphone("Iphone 11",75000,"red");
		smartphone sm2=new smartphone("Iphone 12",60000,"blue");
		smartphone sm3=new smartphone("galaxy flip 12",132424,"white");
		smartphone sm4=new smartphone("iqoo z7",39700,"blue");
		employee e1=new employee("jonha",1);
		employee e2=new employee("Karthik",2);
		employee e3=new employee("Ram",3);
		customer c1=new customer("A",80000);
		customer c2=new customer("B",10000);
		customer c3=new customer("C",900000);
		c1.buy(sm1);
		e1.sellphone(c1,sm1);
	}
}
